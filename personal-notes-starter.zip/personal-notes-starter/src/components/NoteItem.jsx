import React from "react";
import NoteItemBody from "./NoteItemBody";
import DeleteButton from "./Deleteutton";

function NoteItem({title, note, id, onDelete}) {
    return (
        <div className="note-item">
            <NoteItemBody title={item} tag={tag} />
            <DeleteButton id={id} onDelete={onDelete} />
        </div>
    );
}

export default NoteItem;