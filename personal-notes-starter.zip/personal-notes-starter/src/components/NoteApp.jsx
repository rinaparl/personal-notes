import React from "react";
import NoteList from "./NoteList";
import {getData} from "../utils/index";
import NoteInput from "./NoteInput";

class NoteApp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            contacts: getData(),
        }

        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.onAddNoteHandler = this.onAddNoteHandler.bind(this);
    }

    onDeleteHandler(id) {
        const notes = this.state.notes.filter(note => note.id !== id);
        this.setState({notes});
    }

    onAddNoteHandler({title, note}) {
        this.setState((prevState) => {
            return {
                notes: [
                    ...prevState.notes,
                    {
                        id: +new Date(),
                        title,
                        note,
                    }
                ]
            }
        });
    }

    render() {
        return (
            <div className="note-app__body">
                <h1>Personal Note</h1>
                <h2>Tambah Catatan</h2>
                <NoteInput addNote={this.onAddNoteHandler}/>
                <h2>Catatan Aktif</h2>
                <NoteList notes={this.state.notes} onDelete={this.onDeleteHandler} />
                <h2>Arsip</h2>
                
            </div>
        );
    }
}


export default NoteApp;